//
//  AheadTLV.h
//  AheadTLV
//
//  Created by Jakub Mejtský on 29/10/2018.
//  Copyright © 2018 AHEAD iTec, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AheadTLV.
FOUNDATION_EXPORT double AheadTLVVersionNumber;

//! Project version string for AheadTLV.
FOUNDATION_EXPORT const unsigned char AheadTLVVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AheadTLV/PublicHeader.h>


